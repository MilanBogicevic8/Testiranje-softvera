/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import static org.testng.Assert.*;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

/**
 *
 * @author Korisnik
 */
public class Registracija {
    
    public Registracija() {
    }

    // TODO add test methods here.
    // The methods must be annotated with annotation @Test. For example:
    //
    // @Test
    // public void hello() {}

    public static String baseURL="http://localhost/Projekat4/ankete2/login.php#";//pocetna putanja\

    public static WebDriver driver;
    
     @Test
     void ChromeTest1(){ //uspesna registracija
        
        try{
        System.setProperty("webdriver.chrome.driver","C:\\chromedriver.exe");  //pazi cesto se negadjaju verzije
        driver=new ChromeDriver(); //ovako se dodajer driver
        driver.get(baseURL); // vezujemo se za adresu u8 hromu
        
        driver.findElement(By.xpath("/html/body/div/div[2]/div[2]/ul/li[2]/a")).click();//prelazak u registraciju
        String username="Milan11";
        String lozinka="Milan123";
        String potvrda_lozinke="Milan123";
        String ime="Milan";
        String prezime="Bogicevic";
        String JMBG="0808001710238";
        String datum="08082001";
        String mesto="Smederevo";
        String telefon="+381644475572";
        String mejl="a@b.rs";
        
        driver.findElement(By.name("username2")).sendKeys(username);
        driver.findElement(By.name("password2")).sendKeys(lozinka);
        driver.findElement(By.name("password22")).sendKeys(potvrda_lozinke);
        driver.findElement(By.name("ime")).sendKeys(ime);
        driver.findElement(By.name("prezime")).sendKeys(prezime);
        driver.findElement(By.name("jmbg")).sendKeys(JMBG);
        driver.findElement(By.name("datum")).sendKeys(datum);
        driver.findElement(By.name("mesto")).sendKeys(mesto);
        driver.findElement(By.name("telefon")).sendKeys(telefon);
        driver.findElement(By.name("mejl")).sendKeys(mejl);
        //driver.findElement(By.name("tipkor")).click();
        
        
        
        driver.findElement(By.name("regdugme")).click();
        
        String t1="111";
        Alert simpleAlert=driver.switchTo().alert();
        String text=simpleAlert.getText();
        simpleAlert.accept();
        //System.out.println(text.equals(t1));
        Assert.assertTrue(text.contains(t1));
        //Assert.assertEquals(text, text);
        
        String t2="222";
        text=simpleAlert.getText();
        simpleAlert.accept();
        System.out.println(text);
        Assert.assertTrue(text.contains(t2));
         
        String t3="Uspešno ste se registrovali!";
        text=simpleAlert.getText();
        simpleAlert.accept();
        System.out.println(text);
        
        Assert.assertTrue(text.contains(t3));
       
        }catch(Exception e){
            e.printStackTrace();
            
        }
        
        if(driver!=null){
            driver.quit();
        }
    }
     
     
    @Test
    void chromeTest2(){
        
        //prihvatanje korisnika Milan11 od strane administratora
        
        try{
        System.setProperty("webdriver.chrome.driver","C:\\chromedriver.exe");  //pazi cesto se negadjaju verzije
        driver=new ChromeDriver(); //ovako se dodajer driver
        driver.get(baseURL); // vezujemo se za adresu u8 hromu
        
        
        String username="admin";
        String lozinka="Admin123.";
        
        
        driver.findElement(By.xpath("//*[@id=\"log\"]/form/div[1]/input")).sendKeys(username);
        driver.findElement(By.xpath("//*[@id=\"log\"]/form/div[2]/input")).sendKeys(lozinka);
        
        
        driver.findElement(By.xpath("//*[@id=\"log\"]/form/button")).click();
        String text1="Dobro došli na sajt!";
        String text=driver.findElement(By.xpath("/html/body/div/div[2]/h1")).getText();
        //System.out.println(text);
        Assert.assertTrue(text.contains(text1));
        
        driver.findElement(By.xpath("/html/body/div/div[1]/nav/ul/li[6]/a")).click();  //klik na registraciju
        
        
        
        text=driver.findElement(By.xpath("//*[@id=\"regtable\"]/tbody/tr[3]/td[4]/button[1]")).getText();
        text1="ODOBRI";
        //System.out.println(text);
        Assert.assertTrue(text.contains(text1));
        driver.findElement(By.xpath("//*[@id=\"regtable\"]/tbody/tr[3]/td[4]/button[1]")).click();
       
        }catch(Exception e){
            e.printStackTrace();
            
        }
        
        if(driver!=null){
            driver.quit();
        }
        
    }
   @Test
    void chromeTest3(){
        //registracija korisnika koji vec postoji
        
        
        try{
        System.setProperty("webdriver.chrome.driver","C:\\chromedriver.exe");  //pazi cesto se negadjaju verzije
        driver=new ChromeDriver(); //ovako se dodajer driver
        driver.get(baseURL); // vezujemo se za adresu u8 hromu
        
        driver.findElement(By.xpath("/html/body/div/div[2]/div[2]/ul/li[2]/a")).click();
        String username="Milan11";
        String lozinka="Milan123";
        String potvrda_lozinke="Milan123";
        String ime="Milan";
        String prezime="Bogicevic";
        String JMBG="0808001710238";
        String datum="08082001";
        String mesto="Smederevo";
        String telefon="+381644475572";
        String mejl="a@b.rs";
        
        driver.findElement(By.name("username2")).sendKeys(username);
        driver.findElement(By.name("password2")).sendKeys(lozinka);
        driver.findElement(By.name("password22")).sendKeys(potvrda_lozinke);
        driver.findElement(By.name("ime")).sendKeys(ime);
        driver.findElement(By.name("prezime")).sendKeys(prezime);
        driver.findElement(By.name("jmbg")).sendKeys(JMBG);
        driver.findElement(By.name("datum")).sendKeys(datum);
        driver.findElement(By.name("mesto")).sendKeys(mesto);
        driver.findElement(By.name("telefon")).sendKeys(telefon);
        driver.findElement(By.name("mejl")).sendKeys(mejl);
        //driver.findElement(By.name("tipkor")).click();
        
        
        
        driver.findElement(By.name("regdugme")).click();
        
        String t1="111";
        Alert simpleAlert=driver.switchTo().alert();
        String text=simpleAlert.getText();
        simpleAlert.accept();
        //System.out.println(text.equals(t1));
        Assert.assertTrue(text.contains(t1));
        //Assert.assertEquals(text, text);
        
        String t2="222";
        text=simpleAlert.getText();
        simpleAlert.accept();
        System.out.println(text);
        Assert.assertTrue(text.contains(t2));
         
        String t3="Takav korisnik već postoji!";
        text=simpleAlert.getText();
        simpleAlert.accept();
        System.out.println(text);
        
        Assert.assertTrue(text.contains(t3));
       
        }catch(Exception e){
            e.printStackTrace();
            
        }
        
        if(driver!=null){
            driver.quit();
        }
    }
    
    @Test
    void chromeTest4(){
        //registracija- datum rodjenja u buducnosti
        
         try{
        System.setProperty("webdriver.chrome.driver","C:\\chromedriver.exe");  //pazi cesto se negadjaju verzije
        driver=new ChromeDriver(); //ovako se dodajer driver
        driver.get(baseURL); // vezujemo se za adresu u8 hromu
        
        driver.findElement(By.xpath("/html/body/div/div[2]/div[2]/ul/li[2]/a")).click();
        String username="Milan11";
        String lozinka="Milan123";
        String potvrda_lozinke="Milan123";
        String ime="Milan";
        String prezime="Bogicevic";
        String JMBG="2212222710213";
        String datum="22122222";
        String mesto="Smederevo";
        String telefon="+381644475572";
        String mejl="a@b.rs";
        
        driver.findElement(By.name("username2")).sendKeys(username);
        driver.findElement(By.name("password2")).sendKeys(lozinka);
        driver.findElement(By.name("password22")).sendKeys(potvrda_lozinke);
        driver.findElement(By.name("ime")).sendKeys(ime);
        driver.findElement(By.name("prezime")).sendKeys(prezime);
        driver.findElement(By.name("jmbg")).sendKeys(JMBG);
        driver.findElement(By.name("datum")).sendKeys(datum);
        driver.findElement(By.name("mesto")).sendKeys(mesto);
        driver.findElement(By.name("telefon")).sendKeys(telefon);
        driver.findElement(By.name("mejl")).sendKeys(mejl);
        //driver.findElement(By.name("tipkor")).click();
        
        
        
        driver.findElement(By.name("regdugme")).click();
        
        String t1="111";
        Alert simpleAlert=driver.switchTo().alert();
        String text=simpleAlert.getText();
        simpleAlert.accept();
        //System.out.println(text.equals(t1));
        Assert.assertTrue(text.contains(t1));
        //Assert.assertEquals(text, text);
        
        String t2="222";
        text=simpleAlert.getText();
        simpleAlert.accept();
        System.out.println(text);
        Assert.assertTrue(text.contains(t2));
         
        String t3="Neispravan datum!";// ovde ce da failuje- ispisace netacan jmbg samo
        text=simpleAlert.getText();
        simpleAlert.accept();
        System.out.println(text);
        
        Assert.assertTrue(text.contains(t3));
       
        }catch(Exception e){
            e.printStackTrace();
            
        }
        
        if(driver!=null){
            driver.quit();
        }
    }
    
    @Test
    void chromeTest5(){
        //registracija- mejl nema @
        
         try{
        System.setProperty("webdriver.chrome.driver","C:\\chromedriver.exe");  //pazi cesto se negadjaju verzije
        driver=new ChromeDriver(); //ovako se dodajer driver
        driver.get(baseURL); // vezujemo se za adresu u8 hromu
        
        driver.findElement(By.xpath("/html/body/div/div[2]/div[2]/ul/li[2]/a")).click();
        String username="Milan11";
        String lozinka="Milan123";
        String potvrda_lozinke="Milan123";
        String ime="Milan";
        String prezime="Bogicevic";
        String JMBG="0808001710238";
        String datum="08082001";
        String mesto="Smederevo";
        String telefon="+381644475572";
        String mejl="ab.rs";
        
        driver.findElement(By.name("username2")).sendKeys(username);
        driver.findElement(By.name("password2")).sendKeys(lozinka);
        driver.findElement(By.name("password22")).sendKeys(potvrda_lozinke);
        driver.findElement(By.name("ime")).sendKeys(ime);
        driver.findElement(By.name("prezime")).sendKeys(prezime);
        driver.findElement(By.name("jmbg")).sendKeys(JMBG);
        driver.findElement(By.name("datum")).sendKeys(datum);
        driver.findElement(By.name("mesto")).sendKeys(mesto);
        driver.findElement(By.name("telefon")).sendKeys(telefon);
        driver.findElement(By.name("mejl")).sendKeys(mejl);
        //driver.findElement(By.name("tipkor")).click();
        
        
        
        driver.findElement(By.name("regdugme")).click();
        
        String t1="111";
        Alert simpleAlert=driver.switchTo().alert();
        String text=simpleAlert.getText();
        simpleAlert.accept();
        //System.out.println(text.equals(t1));
        Assert.assertTrue(text.contains(t1));
        //Assert.assertEquals(text, text);
        
        String t2="222";
        text=simpleAlert.getText();
        simpleAlert.accept();
        System.out.println(text);
        Assert.assertTrue(text.contains(t2));
         
        String t3="Please include an '@' in the email address.'ab.rs' is missing an '@'.";
        text=simpleAlert.getText();
        simpleAlert.accept();
        System.out.println(text);
        
        Assert.assertTrue(text.contains(t3));
       
        }catch(Exception e){
            e.printStackTrace();
            
        }
        
        if(driver!=null){
            driver.quit();
        }
    }
    
    @Test
    void chromeTest6(){
        
        //razlicita lozinka i potvrda lozinke
        
        try{
        System.setProperty("webdriver.chrome.driver","C:\\chromedriver.exe");  //pazi cesto se negadjaju verzije
        driver=new ChromeDriver(); //ovako se dodajer driver
        driver.get(baseURL); // vezujemo se za adresu u8 hromu
        
        driver.findElement(By.xpath("/html/body/div/div[2]/div[2]/ul/li[2]/a")).click();
        String username="Milan11";
        String lozinka="Milan123";
        String potvrda_lozinke="Milan1234";
        String ime="Milan";
        String prezime="Bogicevic";
        String JMBG="0808001710238";
        String datum="08082001";
        String mesto="Smederevo";
        String telefon="+381644475572";
        String mejl="ab.rs";
        
        driver.findElement(By.name("username2")).sendKeys(username);
        driver.findElement(By.name("password2")).sendKeys(lozinka);
        driver.findElement(By.name("password22")).sendKeys(potvrda_lozinke);
        driver.findElement(By.name("ime")).sendKeys(ime);
        driver.findElement(By.name("prezime")).sendKeys(prezime);
        driver.findElement(By.name("jmbg")).sendKeys(JMBG);
        driver.findElement(By.name("datum")).sendKeys(datum);
        driver.findElement(By.name("mesto")).sendKeys(mesto);
        driver.findElement(By.name("telefon")).sendKeys(telefon);
        driver.findElement(By.name("mejl")).sendKeys(mejl);
        //driver.findElement(By.name("tipkor")).click();
        
        
        
        driver.findElement(By.name("regdugme")).click();
        
        String t1="111";
        Alert simpleAlert=driver.switchTo().alert();
        String text=simpleAlert.getText();
        simpleAlert.accept();
        //System.out.println(text.equals(t1));
        Assert.assertTrue(text.contains(t1));
        //Assert.assertEquals(text, text);
        
        String t2="222";
        text=simpleAlert.getText();
        simpleAlert.accept();
        System.out.println(text);
        Assert.assertTrue(text.contains(t2));
         
        String t3="Lozinke se moraju slagati!";
        text=simpleAlert.getText();
        simpleAlert.accept();
        System.out.println(text);
        
        Assert.assertTrue(text.contains(t3));
       
        }catch(Exception e){
            e.printStackTrace();
            
        }
        
        if(driver!=null){
            driver.quit();
        }
    }
    
    @Test
    void chromeTest7(){
        ///pravljenje sluybenika- koriscenje padajuceg
        try{
        System.setProperty("webdriver.chrome.driver","C:\\chromedriver.exe");  //pazi cesto se negadjaju verzije
        driver=new ChromeDriver(); //ovako se dodajer driver
        driver.get(baseURL); // vezujemo se za adresu u8 hromu
        
        driver.findElement(By.xpath("/html/body/div/div[2]/div[2]/ul/li[2]/a")).click();//prelazak u registraciju
        String username="MilanSluzba";
        String lozinka="Milan123";
        String potvrda_lozinke="Milan123";
        String ime="Milan";
        String prezime="Bogicevic";
        String JMBG="0808001710238";
        String datum="08082001";
        String mesto="Beograd";
        String telefon="+381644475572";
        String mejl="a@b.rs";
        
        driver.findElement(By.name("username2")).sendKeys(username);
        driver.findElement(By.name("password2")).sendKeys(lozinka);
        driver.findElement(By.name("password22")).sendKeys(potvrda_lozinke);
        driver.findElement(By.name("ime")).sendKeys(ime);
        driver.findElement(By.name("prezime")).sendKeys(prezime);
        driver.findElement(By.name("jmbg")).sendKeys(JMBG);
        driver.findElement(By.name("datum")).sendKeys(datum);
        driver.findElement(By.name("mesto")).sendKeys(mesto);
        driver.findElement(By.name("telefon")).sendKeys(telefon);
        driver.findElement(By.name("mejl")).sendKeys(mejl);
        driver.findElement(By.xpath("//*[@id=\"reg\"]/form/div[11]/select/option[2]")).click();
        //driver.findElement(By.name("tipkor")).click();
        
        
        
        driver.findElement(By.name("regdugme")).click();
        
        String t1="111";
        Alert simpleAlert=driver.switchTo().alert();
        String text=simpleAlert.getText();
        simpleAlert.accept();
        //System.out.println(text.equals(t1));
        Assert.assertTrue(text.contains(t1));
        //Assert.assertEquals(text, text);
        
        String t2="222";
        text=simpleAlert.getText();
        simpleAlert.accept();
        System.out.println(text);
        Assert.assertTrue(text.contains(t2));
         
        String t3="Uspešno ste se registrovali!";
        text=simpleAlert.getText();
        simpleAlert.accept();
        System.out.println(text);
        
        Assert.assertTrue(text.contains(t3));
       
        }catch(Exception e){
            e.printStackTrace();
            
        }
        
        if(driver!=null){
            driver.quit();
        }
        
    }
    
    @BeforeClass
    public static void setUpClass() throws Exception {
    }

    @AfterClass
    public static void tearDownClass() throws Exception {
    }

    @BeforeMethod
    public void setUpMethod() throws Exception {
    }

    @AfterMethod
    public void tearDownMethod() throws Exception {
    }
}


//ovo je bio chrome driver


//u firefox primeru ce se praviti autor koji ce se u narednom testu azurirati i u trecem testu ce se brisati
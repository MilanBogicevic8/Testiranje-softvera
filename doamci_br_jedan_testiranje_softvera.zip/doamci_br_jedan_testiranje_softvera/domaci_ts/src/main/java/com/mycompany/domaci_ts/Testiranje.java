/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.domaci_ts;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;

/**
 *
 * @author Korisnik
 */
public class Testiranje {
    
    public static String baseURL="http://localhost/Projekat4/ankete2/login.php#";//pocetna putanja\

    public static WebDriver driver;
    
    public static void main(String[] args) {
        
        try{
        System.setProperty("webdriver.chrome.driver","C:\\chromedriver.exe");  //pazi cesto se negadjaju verzije
        driver=new ChromeDriver(); //ovako se dodajer driver
        driver.get(baseURL); // vezujemo se za adresu u8 hromu
        
        
        String username="admin";
        String lozinka="Admin123.";
        
        
        driver.findElement(By.xpath("//*[@id=\"log\"]/form/div[1]/input")).sendKeys(username);
        driver.findElement(By.xpath("//*[@id=\"log\"]/form/div[2]/input")).sendKeys(lozinka);
        
        
        driver.findElement(By.xpath("//*[@id=\"log\"]/form/button")).click();
        String text1="Dobro došli na sajt!";
        String text=driver.findElement(By.xpath("/html/body/div/div[2]/h1")).getText();
        //System.out.println(text);
        Assert.assertTrue(text.contains(text1));
        
        driver.findElement(By.xpath("/html/body/div/div[1]/nav/ul/li[6]/a")).click();  //klik na registraciju
        
        
        
        text=driver.findElement(By.xpath("//*[@id=\"regtable\"]/tbody/tr[3]/td[4]/button[1]")).getText();
        text1="ODOBRI";
        //System.out.println(text);
        Assert.assertTrue(text.contains(text1));
        driver.findElement(By.xpath("//*[@id=\"regtable\"]/tbody/tr[3]/td[4]/button[1]")).click();
       
        }catch(Exception e){
            e.printStackTrace();
            
        }
        
        if(driver!=null){
            driver.quit();
        }
        
    }
        
    
}


import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.Assert;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Korisnik
 */
public class Test {
    
    
    public static String baseURL="http://localhost/Projekat4/ankete2/login.php";//pocetna putanja\

    public static WebDriver driver;
    
    
    
    public static void main(String[] args) {
        
    
    try{
        System.setProperty("webdriver.gecko.driver","C:\\geckodriver.exe");  //pazi cesto se negadjaju verzije
        driver=new FirefoxDriver(); //ovako se dodajer driver
        driver.get(baseURL); // vezujemo se za adresu u8 hromu
        
        driver.findElement(By.xpath("/html/body/div/div[2]/div[2]/ul/li[2]/a")).click();//prelazak u registraciju
        String username="Milan20";
        String lozinka="Milan123";
        String potvrda_lozinke="Milan123";
        String ime="Milan";
        String prezime="Bogicevic";
        String JMBG="0808001710238";
        String datum="08082001";
        String mesto="Smederevo";
        String telefon="+381644475572";
        String mejl="a@b.rs";
        
        driver.findElement(By.name("username2")).sendKeys(username);
        driver.findElement(By.name("password2")).sendKeys(lozinka);
        driver.findElement(By.name("password22")).sendKeys(potvrda_lozinke);
        driver.findElement(By.name("ime")).sendKeys(ime);
        driver.findElement(By.name("prezime")).sendKeys(prezime);
        driver.findElement(By.name("jmbg")).sendKeys(JMBG);
        driver.findElement(By.name("datum")).sendKeys(datum);
        driver.findElement(By.name("mesto")).sendKeys(mesto);
        driver.findElement(By.name("telefon")).sendKeys(telefon);
        driver.findElement(By.name("mejl")).sendKeys(mejl);
        //driver.findElement(By.name("tipkor")).click();
        
        
        
        driver.findElement(By.name("regdugme")).click();
        
        String t1="111";
        Alert simpleAlert=driver.switchTo().alert();
        String text=simpleAlert.getText();
        simpleAlert.accept();
        //System.out.println(text.equals(t1));
        Assert.assertTrue(text.contains(t1));
        //Assert.assertEquals(text, text);
        
        String t2="222";
        text=simpleAlert.getText();
        simpleAlert.accept();
        System.out.println(text);
        Assert.assertTrue(text.contains(t2));
         
        String t3="Uspešno ste se registrovali!";
        text=simpleAlert.getText();
        simpleAlert.accept();
        System.out.println(text);
        
        Assert.assertTrue(text.contains(t3));
       
        }catch(Exception e){
            e.printStackTrace();
            
        }
        
        if(driver!=null){
            driver.quit();
        }
    }
}
